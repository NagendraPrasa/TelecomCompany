package com.DAO;

public interface IssueDAO {
	public void solveIssue(String solution);
}

package com.DAO;

public interface AdministratorDAO {
	public void changePlan();
}

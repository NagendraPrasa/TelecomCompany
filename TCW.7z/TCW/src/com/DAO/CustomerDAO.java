package com.DAO;

public interface CustomerDAO {
	public void buyPlan();
	public void rechargeOnline();
	public void payOnline();
}

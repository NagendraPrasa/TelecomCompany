package com.service;

import com.DAO.IssueDAO;

public class IssueService implements IssueDAO{
	public void solveIssue(String solution) {
		
	}
}

package com.service;

import com.DAO.AdministratorDAO;

public class AdministratorService implements AdministratorDAO{
	public void changePlan() {
		
	}
}

package com.service;

import com.DAO.CustomerDAO;

public class CustomerService implements CustomerDAO{
	public void buyPlan(){
		
	}
	public void rechargeOnline(){
		
	}
	public void payOnline() {
		
	}
}
